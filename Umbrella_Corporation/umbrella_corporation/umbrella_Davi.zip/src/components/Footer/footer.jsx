import "bootstrap/dist/css/bootstrap.min.css";

export default function Footer() {
    return (
        <>
        <footer>
            <div className="d-flex align-items-center justify-content-center w-100">
                <p>©All rights reserveds by Davi Leocadio | 2025</p>
            </div>
        </footer>
            
        </>
    )
}